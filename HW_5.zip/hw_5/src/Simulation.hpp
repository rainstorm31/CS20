/*
 * Simulation.hpp
 *
 *  Created on: Apr 2, 2021
 *      Author: Zonghui
 */

#ifndef SIMULATION_HPP_
#define SIMULATION_HPP_
#include "ArrayQueue.hpp"
#include "Barista.hpp"
#include "Customer.hpp"

class Simulation {
private:
	ArrayQueue<Customer*> *custQ;
	Barista* bari1;
	Barista* bari2;
	int epochs;
	double avgWaitTime;
	void finish(Barista* b, int ct);
	void help(Barista*b , int ct);
public:
	Simulation(int e, int c);
	virtual ~Simulation();
	void run();
};

#endif /* SIMULATION_HPP_ */

/*
 * Simulation.cpp
 *
 *  Created on: Apr 2, 2021
 *      Author: Zonghui
 */

#include "Simulation.hpp"
#include <cstdlib>
#include <ctime>

Simulation::Simulation(int e, int c ) {
custQ = new ArrayQueue<Customer*>(c);
bari1 = new Barista(1);
bari2 = new Barista(2);
epochs = e;
avgWaitTime = 0;

}

Simulation::~Simulation() {
	delete bari1;
	delete bari2;
	delete custQ;

}
void Simulation:: help(Barista* b, int ct){
	int r = rand()%6+5;

	b->setCurrentCustomer(custQ->front());
	b->setStartTime(ct);
	b->setEndTime(ct+r);
	cout << "Barista " << b->getId() << " is helping customer # " << b->getCurrentCustomer()->getId() << " at time " << ct <<endl;
	custQ->dequeue();

}

void Simulation:: finish(Barista* b, int ct){

	b->updateTotal();

	int wt = ct-b->getCurrentCustomer()->getStartTime();

	avgWaitTime += wt;


	cout <<"Customer #" << b->getCurrentCustomer()->getId() << " finished at time " << ct <<endl;

	delete b->getCurrentCustomer();
	b->setCurrentCustomer(nullptr);

}

void Simulation:: run(){

	int c_id = 1;


	for ( int curr_time = 1 ; curr_time <= 100 ; curr_time++){

		int r = rand()% 100;
		if(r <= 30){
			Customer *a = new Customer(c_id, curr_time);

			if (!custQ->isFull()){
				custQ->enqueue(a);
				cout << "Customer # " << c_id << " enter the queue at time " << curr_time << endl;
				c_id ++;
				}
			}
		// check if bari1 or bari2 can help
		if (bari1->getCurrentCustomer()==nullptr&& (!custQ->isEmpty())){
			help(bari1,curr_time);
			}

		else if (bari2->getCurrentCustomer()==nullptr&& !custQ->isEmpty() ){
			help(bari2,curr_time);
			}

		// check if any Barista finished help customer
		if (bari1->getEndTime() == curr_time ){
			finish(bari1,curr_time);
		}
	   if (bari2->getEndTime() == curr_time ){
			finish(bari2,curr_time);
			}
	}// end of for loop

	cout << endl;
	cout << " SIMULATION FINISHED" << endl;
	cout << endl;
	cout << " Barista #1 helped " << bari1->getTotal() << " customers. " << endl;
	cout << " Barista #2 helped " << bari2->getTotal() << " customers. " << endl;
	cout << " Average wait time for a customer :" << avgWaitTime/(bari1->getTotal()+bari2->getTotal()) << endl;


}
